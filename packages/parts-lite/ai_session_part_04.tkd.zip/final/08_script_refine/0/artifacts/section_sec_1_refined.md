# 宝德基于 intelligence boom 的推理优化及智能应用实践分享

本次分享将介绍宝德计算机在以下两个方面的实践与思考：

*   **推理优化与智能应用**：基于 intelligence boom 的实践分享。
*   **与 openEuler 的合作**：相关的实践与思考。